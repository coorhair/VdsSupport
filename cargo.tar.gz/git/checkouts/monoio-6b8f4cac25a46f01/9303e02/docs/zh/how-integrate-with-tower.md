---
title: 如何与 Tower 兼容
date: 2021-11-24 20:00:00
author: ihciah
---

# 如何与 Tower 兼容

使用了 GAT 的情况下 Future 会带上生命周期，我们可能需要其他方式来使用 Tower 这套组件和抽象。

TODO