# Security Policy

## Reporting a Vulnerability

Security reporting is welcomed.

Please report security issues via [chihai.hain@bytedance.com](mailto:chihai.hain@bytedance.com). Security issues should not be reported via the public Github Issue tracker.
